![Gravatar](http://cl.ly/image/3N3S0T2S3a3h/Capture%20d%E2%80%99%C3%A9cran%202013-11-29%20%C3%A0%2022.52.06.jpg)
![Gravatar Admin](http://f.cl.ly/items/0Y342a2s302R0W143I3o/Capture%20d%E2%80%99%C3%A9cran%202013-11-17%20%C3%A0%2018.32.39.jpg)

Je suis ouvert à toute idée d'amélioration et suis disponible si vous avez des soucis. ;)