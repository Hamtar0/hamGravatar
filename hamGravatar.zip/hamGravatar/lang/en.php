<?php

$LANG = array(

'SPAM_LIST'					=> 'Spam list',

# config.php
'L_SAVE'					=> 'Save',

);
?>