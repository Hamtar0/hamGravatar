<?php

$LANG = array(

'SPAM_LIST'					=> 'Liste des spams',

# config.php
'L_SAVE'					=> 'Enregistrer',

);
?>